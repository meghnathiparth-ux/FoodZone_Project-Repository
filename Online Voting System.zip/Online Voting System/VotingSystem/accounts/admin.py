from django.contrib import admin
from accounts.models import *
# Register your models here.
class UsersAdmin(admin.ModelAdmin):
    list_display = ('id','user_name','user_email','user_password','user_pincode')

admin.site.register(RegisterUser,UsersAdmin)