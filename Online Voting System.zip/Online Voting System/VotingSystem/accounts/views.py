from django.shortcuts import render , redirect
from django.contrib import messages
from accounts.models import *
from django.contrib.auth.hashers import make_password , check_password
# Create your views here.
def login_page(request):
    user_data = None
    if 'userid' in request.session:
        user_data = RegisterUser.objects.filter(id=request.session['userid']).first()
    
    return render(request, 'accounts/login.html', {'logged_in_user': user_data})

def register_user(request):
    if request.method == "POST":
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        pincode = request.POST['pincode']
        # Password Increept
        hash_pass = make_password(password)
        if RegisterUser.objects.filter(user_email = email).exists():
            messages.warning(request , "The User Already Exists.")
            return redirect('login_page')
        else:
            user = RegisterUser.objects.create(
                user_name = username ,
                user_email = email ,
                user_password = hash_pass,
                user_pincode = pincode
            )
            user.save()
            messages.success(request , "The User Register Successfully.")
    return redirect('login_page')

def login_user(request):
    if request.method == "POST":
        email = request.POST['email']
        password = request.POST['password']
        user = RegisterUser.objects.filter(user_email = email).first()
        # print(user.id)
        if user and check_password(password, user.user_password):
            request.session['userid'] = user.id
            # request.session['useremail'] = user.user_email
            messages.success(request,f"Welcome, {user.user_name}")
            return redirect('home')
        else:
            messages.warning(request,"You Are Not Logged in.")
            return redirect('login_page')
    return redirect('login_page')

def logout_user(request):
    # This deletes all session data and the session cookie
    del request.session['userid']
    messages.success(request, "You have been logged out successfully.")
    return redirect('login_page')