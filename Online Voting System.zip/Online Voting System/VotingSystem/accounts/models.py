from django.db import models

# Create your models here.
class RegisterUser(models.Model):
    user_name = models.CharField(max_length=400)
    user_email = models.EmailField()
    user_password = models.CharField(max_length=30)
    user_pincode = models.BigIntegerField(null=True,blank=True)

    def __str__(self):
        return self.user_name