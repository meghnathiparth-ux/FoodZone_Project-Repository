from django.db import models
from accounts.models import *
from django.utils import timezone
# Create your models here.
class Election_Partie(models.Model):
    party_name = models.CharField(max_length=400)
    party_subname = models.CharField(max_length=150)
    party_symbol = models.ImageField(upload_to="static/partysymbol")
    party_flag = models.ImageField(upload_to="static/partyflag")
    party_leader_nm = models.CharField(max_length=250) 
    party_leader = models.ImageField(upload_to="static/partyleader")

    def __str__(self):
        return self.party_name

class Vote(models.Model):
    voter = models.OneToOneField(
        RegisterUser,
        on_delete=models.CASCADE,
        related_name="vote"
    )
    selected_party = models.ForeignKey(
        Election_Partie,
        on_delete=models.CASCADE,
        related_name="votes"
    )
    voted_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.voter} → {self.selected_party}"
    