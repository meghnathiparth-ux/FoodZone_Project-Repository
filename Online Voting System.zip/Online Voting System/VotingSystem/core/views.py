from django.shortcuts import render , redirect , get_object_or_404
from core.models import *
from accounts.models import *
from django.contrib import messages

# Create your views here.
def home(request):
    return render(request,'core/index.html')

def about(request):
    return render(request,'core/about.html')

def elections(request):
 # 1. Check if the user is logged in by looking for 'userid' in the session
    if 'userid' not in request.session:
        # 2. If not logged in, show a warning message
        messages.warning(request, "Please login first to access the election page.")
        # 3. Redirect them to the login page
        return redirect('login_page')

    # 4. If logged in, fetch the parties and show the page
    # (Assuming your party model is named 'Party')
    party = Election_Partie.objects.all() 
    return render(request, 'core/elections.html',{'party': party})

def addvote(request):
    if request.method == "POST":
        # Get Party Name In Form
        partyid = request.POST['party']
        print(partyid)
        # Get Party Object Of Model Election_Parties
        party = get_object_or_404(Election_Partie, id=partyid)
        # Get UserId In Used Of Session
        user_id = request.session['userid']
        # Get Voter Of The Model
        user = get_object_or_404(RegisterUser, id=user_id)
        if Vote.objects.filter(voter = user).exists():
            messages.warning(request,"You Have Already Voted.")
            return redirect("elections")
        Vote.objects.create(
            voter=user,
            selected_party=party,
        )
    return render(request,'core/voted.html')
