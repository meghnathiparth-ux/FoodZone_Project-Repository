from django.contrib import admin
from core.models import *
# Register your models here.

# Election Party
class Election_Party_Admin(admin.ModelAdmin):
    list_display = ('party_name','party_subname','party_symbol','party_flag','party_leader_nm','party_leader',)
admin.site.register(Election_Partie,Election_Party_Admin)

# Vote
class Vote_Admin(admin.ModelAdmin):
    list_display = ('voter','selected_party','voted_at')
admin.site.register(Vote,Vote_Admin)