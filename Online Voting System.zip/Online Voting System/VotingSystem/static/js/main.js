// Highlight selected party row with green background
const radios = document.querySelectorAll('input[type=radio][name=party]');
radios.forEach(radio => {
  radio.addEventListener('change', () => {
    document.querySelectorAll('.party-row').forEach(row => row.style.backgroundColor = '#fff');
    radio.closest('.party-row').style.backgroundColor = '#d4edda';
  });
});

// Auto Redirect Script 
let seconds = 15;
let countdown = document.getElementById("countdown");
console.log(countdown)
setInterval(() => {
  seconds--;
  countdown.innerText = seconds;
  if (seconds <= 0) {
    window.location.href = "/";
  }
}, 1000);