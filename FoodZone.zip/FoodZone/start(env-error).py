# THIS LINE CODE PAST & START VIRTUAL ENVIROMENT 
# <-- Set-ExecutionPolicy RemoteSigned -Scope Process -->