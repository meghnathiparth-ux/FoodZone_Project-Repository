from django.db import models
from django.contrib.auth.models import User
from store.models import *
from accounts.models import *
# Create your models here.

class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Products, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    added_on = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.product.name} ({self.quantity})"

    @property
    def total_price(self):
        return self.quantity * self.product.price


class PaymentOrder(models.Model):
    PAYMENT_CHOICES = [
        ("COD", "Cash on Delivery"),
        ("G-Pay", "Google Pay"),
        ("Phone-Pay", "PhonePe"),
        ("Paypal", "PayPal"),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Products, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    delivery_address = models.TextField()
    payment_method = models.CharField(max_length=20, choices=PAYMENT_CHOICES)
    total_payment = models.PositiveIntegerField(default=0)

    order_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=50, default="Pending")

    def __str__(self):
        return f"{self.user.username} - {self.product.name} - {self.payment_method}"

