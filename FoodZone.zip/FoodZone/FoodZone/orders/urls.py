from django.urls import path
from .import views

urlpatterns = [
    # Cart Page
    path('cart/', views.cart, name='cart'),
    path('add_cart/<slug>/', views.add_to_cart, name='add_to_cart'),
    path('remove_cart/<int:id>/', views.remove_cart, name='remove_cart'),
    # New Cart Checkout URL
    path('checkout/', views.checkout, name='checkout'),
    
    # Payment URLs
    path('payment/', views.payment, name='payment'),
    path('payment/<slug>/', views.paymentor, name='paymentor'),
]