from .models import Cart
from decimal import Decimal

def cart_count(request):
    """
    Returns the count of cart items for the currently logged-in user, 
    making it available in the template context globally.
    """
    cart_item_count = 0
    if request.user.is_authenticated:
        # Assuming Cart model has a ForeignKey to the User model
        cart_item_count = Cart.objects.filter(user=request.user).count()
        
    return {'cart_item_count': cart_item_count}