from django.contrib import admin
from orders.models import *
# Register your models here.

# For Orders
class PaymentOrders_admin(admin.ModelAdmin):
    list_display = ('user','product','quantity','total_payment','delivery_address','payment_method','order_date','status')

admin.site.register(PaymentOrder,PaymentOrders_admin)