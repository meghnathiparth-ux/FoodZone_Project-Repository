from django.shortcuts import render , redirect , get_object_or_404
from store.models import *
from accounts.models import *
from orders.models import *
from django.contrib import messages
from .models import Cart
from django.contrib.auth.decorators import login_required
from decimal import Decimal # <--- IMPORT DECIMAL HERE

# Create your views here.

# Cart Page
# @login_required
def cart(request):
    if not request.user.is_authenticated:
        messages.info(request, "You must login Please.")
        return redirect('home')

    cart_items = Cart.objects.filter(user=request.user)

    subtotal = sum(item.total_price for item in cart_items)
    # Use Decimal for consistent financial calculation
    delivery_fee = Decimal('10.00') # <--- CONVERTED TO DECIMAL
    total = subtotal + delivery_fee

    context = {
        "cart_items": cart_items,
        "subtotal": subtotal,
        "delivery": delivery_fee,
        "total": total
    }

    return render(request, "orders/cart.html", context)

@login_required
def add_to_cart(request, slug):
    product = get_object_or_404(Products, slug=slug)

    # If product already in cart → update quantity
    cart_item, created = Cart.objects.get_or_create(
        user=request.user,
        product=product
    )

    if not created:
        cart_item.quantity += 1

    cart_item.save()
    messages.success(request,"Your Cart Added")
    return redirect("cart")

@login_required
def remove_cart(request, id):
    item = get_object_or_404(Cart, id=id, user=request.user)
    item.delete()
    messages.error(request,"Cart Removed")
    return redirect("cart")


# --- NEW CART CHECKOUT VIEW ---
@login_required
def checkout(request):
    cart_items = Cart.objects.filter(user=request.user)
    
    # Check if cart is empty before proceeding
    if not cart_items:
        messages.error(request, "Your cart is empty. Add items before checking out.")
        return redirect("cart")
        
    subtotal = sum(item.total_price for item in cart_items)
    
    # Use Decimal for consistent financial calculation
    delivery_fee = Decimal('10.00') # <--- CONVERTED TO DECIMAL
    total = subtotal + delivery_fee
    
    if request.method == "POST":
        address = request.POST.get("address")
        payment_method = request.POST.get("paymentMethod")
        
        if not address:
            messages.error(request, "Please provide a delivery address.")
            return render(request, "orders/payment.html", {
                "is_cart_checkout": True,
                "total": total,
                "delivery": delivery_fee,
                "subtotal": subtotal,
            })
            
        # Get the number of items for splitting the fee
        num_items = len(cart_items)
        
        # Calculate the portion of the delivery fee for each item
        # Ensure division result is cast to Decimal if not already, or use Decimal's division method
        # Here, we convert the result of the division to Decimal
        # Note: If num_items is 0, this will raise ZeroDivisionError, but we check for empty cart above.
        fee_per_item = delivery_fee / Decimal(str(num_items))
        
        # Process the order for ALL items in the cart
        for item in cart_items:
            # FIX: total_payment_calculated is item.total_price + fee_per_item (all Decimals)
            total_payment_calculated = item.total_price + fee_per_item
            
            PaymentOrder.objects.create(
                user=request.user,
                product=item.product,
                quantity=item.quantity,
                delivery_address=address,
                payment_method=payment_method,
                total_payment = total_payment_calculated # Now a Decimal
            )
            
        # Clear the cart after successful order creation
        cart_items.delete()
        
        messages.success(request, f"Order placed successfully for a total of ₹{total}!")
        return redirect("home") # Or redirect to an order confirmation page
        
    context = {
        "is_cart_checkout": True, 
        "cart_items": cart_items,
        "total": total,
        "delivery": delivery_fee,
        "subtotal": subtotal,
    }
    
    return render(request, "orders/payment.html", context)


# --- SINGLE PRODUCT PAYMENT VIEWS ---
def payment(request):
    return render(request,"orders/payment.html")

# @login_required
def paymentor(request,slug):
    product = get_object_or_404(Products, slug=slug)
    
    if request.method == "POST":
        qty_str = request.POST.get("quantity")
        address = request.POST.get("address")
        payment_method = request.POST.get("paymentMethod")
    
        if not qty_str or not address:
            messages.error(request, "Please fill in all required fields.")
            return redirect("paymentor", slug=slug)
            
        try:
            quantity_int = int(qty_str)
        except ValueError:
            messages.error(request, "Invalid quantity value.")
            return redirect("paymentor", slug=slug)

        # Use Decimal for calculations
        delivery_fee = Decimal('10.00') # <--- CONVERTED TO DECIMAL
        
        # Ensure product.price is a Decimal (which it should be if using DecimalField)
        # If product.price is guaranteed Decimal, this calculation is safe:
        total_payment_calculated = (Decimal(quantity_int) * product.price) + delivery_fee
    
        PaymentOrder.objects.create(
            user=request.user,
            product=product,
            quantity=quantity_int,
            delivery_address=address,
            payment_method=payment_method,
            total_payment = total_payment_calculated
        )
    
        messages.success(request, "Order placed successfully!")
        return redirect("home")
        
    if not request.user.is_authenticated:
        messages.info(request, "You must login Please.")
        return redirect('home')
        
    return render(request, "orders/payment.html", {"product": product, "is_cart_checkout": False})