// Ensure DOM is ready before manipulating elements Footer
const calendarGrid = document.getElementById('calendar-grid');
const monthHeader = document.getElementById('calendar-month');

const today = new Date();
const currentDate = today.getDate();
const currentMonth = today.toLocaleString('default', { month: 'long' });
const currentYear = today.getFullYear();

monthHeader.textContent = `${currentMonth} ${currentYear}`;

const firstDay = new Date(today.getFullYear(), today.getMonth(), 1).getDay();
const daysInMonth = new Date(today.getFullYear(), today.getMonth()+1, 0).getDate();

const weekdays = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
weekdays.forEach(day => {
    const span = document.createElement('span');
    span.textContent = day;
    calendarGrid.appendChild(span);
});

for(let i=0;i<firstDay;i++){
    const empty = document.createElement('span');
    calendarGrid.appendChild(empty);
}

for(let i=1;i<=daysInMonth;i++){
    const dateSpan = document.createElement('span');
    dateSpan.textContent = i;
    const dayOfWeek = (firstDay + i - 1) % 7;
    if(dayOfWeek === 0 || dayOfWeek === 6){
        dateSpan.classList.add('weekend');
    }
    if(i === currentDate){
        dateSpan.classList.add('today');
    }
    calendarGrid.appendChild(dateSpan);
}
// USER PANEL
function openUserPanel() {
    document.getElementById('userPanel').classList.add('open');
}
function closeUserPanel() {
    document.getElementById('userPanel').classList.remove('open');
}
function showRegister() {
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('registerForm').style.display = 'block';
}
function showLogin() {
    document.getElementById('registerForm').style.display = 'none';
    document.getElementById('loginForm').style.display = 'block';
}

/* HAMBURGER TOGGLE ANIMATION + BORDER + CLOSE BTN */
const toggleBtn = document.getElementById("menuToggleBtn");
const navMenu = document.getElementById("mainNav");
let isOpen = false;

toggleBtn.addEventListener("click", () => {
    isOpen = !isOpen;

    if (isOpen) {
        navMenu.classList.add("show");
        toggleBtn.innerHTML = '<span class="close-icon">&times;</span>';
        toggleBtn.classList.add("rotate");
    } else {
        navMenu.classList.remove("show");
        toggleBtn.innerHTML = '<span class="navbar-toggler-icon"></span>';
        toggleBtn.classList.remove("rotate");
    }
});