"""
URL configuration for FoodZone project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path , include
from FoodZone import views

urlpatterns = [
    # Admin is correctly isolated
    path('admin/', admin.site.urls),

    # 1. Store app: Map to the root for main shop pages
    path('', include('store.urls')),

    # 2. Accounts app: Map all user-related views to a 'user/' or 'accounts/' prefix
    path('accounts/', include('accounts.urls')),

    # 3. Orders app: Map all orders-related views to an 'orders/' prefix
    path('orders/', include('orders.urls')),
]
