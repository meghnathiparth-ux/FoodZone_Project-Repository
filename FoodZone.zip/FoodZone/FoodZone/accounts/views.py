from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User 
from store.models import *
from accounts.models import *
from orders.models import *

# Create your views here.

# Contact Page
def contact(request):
    return render(request, "accounts/contact.html")

# Send Message
def Send_Msg(request):
    # Check if the user is logged in
    if request.user.is_authenticated:
        # The request.user object holds the currently logged-in User instance
        current_user = request.user
        print(current_user)
        # Access user details
        username = current_user.username
        email = current_user.email
        # print(username)
        # print(email)
        if request.method == 'POST':
            full_name = request.POST.get('full_name')
            email     = request.POST.get('email')
            subject     = request.POST.get('subject')
            message     = request.POST.get('message')
            if Contact.objects.filter(Email=email).exists():
                messages.error(request, "Only One Time Pass Message..")
                return redirect('contact')
            else:
                Contact.objects.create(
                    Full_name = full_name,
                    Email = email,
                    Subject = subject,
                    Message = message,
                )
                messages.success(request,"The Message Are Sent")
                return redirect('contact')
    else:
        messages.warning(request,"First Login Please...")
        # print("the User Not Login...")
    return redirect('contact')

# Register

def register_user(request):
    if request.method == 'POST':
        First_name = request.POST.get('First_name')
        Last_name = request.POST.get('Last_name')
        Username = request.POST.get('Username')
        Password = request.POST.get('Password')
        Email = request.POST.get('Email')

        # Input Validation Checks
        if not all([First_name, Last_name, Username, Password, Email]):
             messages.error(request, "All fields are required.")
             return redirect('home') # Redirect to the page that contains the form

        if User.objects.filter(username=Username).exists():
            messages.error(request, "Username already exists. Please choose a different one.")
            return redirect('home') # Redirect to the page that contains the form
        
        if User.objects.filter(email=Email).exists():
            messages.error(request, "Email already registered.")
            return redirect('home') # Redirect to the page that contains the form

        try:
            # Create the user object
            user = User.objects.create(
                first_name = First_name,
                last_name = Last_name,
                username = Username,
                email = Email,
            )
            user.set_password(Password)
            user.save()
            
            # Optionally log the user in immediately after registration
            # user_auth = authenticate(request, username=Username, password=Password)
            # if user_auth is not None:
            #     login(request, user_auth)
            
            messages.success(request, f"Account created successfully for {Username}! You can now log in.")
            return redirect('home') # ***CORRECTED: Redirect to the main page***

        except Exception as e:
            print(f"Error during registration: {e}")
            messages.error(request, "An error occurred during registration. Please try again.")
            return redirect('home') # Redirect to the main page

    # If it's not a POST request, redirect it away from this URL
    return redirect('home') 

# Login 

def login_user(request):
    if request.method == 'POST':
        Username = request.POST.get('Username')
        Password = request.POST.get('Password')
        
        # Authenticate the user
        user = authenticate(request, username=Username, password=Password)
        
        # ***USER NOT LOGIN ISSUE FIX***
        if user is not None:
            # If authentication is successful, log the user in
            login(request, user) # <--- THIS IS WHAT LOGS THE USER IN
            messages.success(request, f"Welcome back, {Username}!")
            return redirect('home') # ***CORRECTED: Redirect to the main page***
        else:
            # If authentication fails
            messages.error(request, "Invalid username or password.")
            return redirect('home') # ***CORRECTED: Redirect to the main page***
    
    # If it's not a POST request, redirect it away from this URL
    return redirect('home')

# Logout
def logout_user(request):
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('home') # ***CORRECTED: Redirect to the main page***