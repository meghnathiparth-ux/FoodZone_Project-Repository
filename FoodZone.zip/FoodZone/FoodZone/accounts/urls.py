from django.urls import path
from .import views

urlpatterns = [
    # Contact Page
    path('contact/', views.contact, name='contact'),

    # Send Message
    path('Message/', views.Send_Msg, name='Message'),

    # Register User (Handles POST submission from header.html)
    path('register/', views.register_user, name='register_user'),
    
    # Login User (Handles POST submission from header.html)
    path('login/', views.login_user, name='login_user'),
    
    # Logout User
    path('logout/', views.logout_user, name='logout_user'),
]