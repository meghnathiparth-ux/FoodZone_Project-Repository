from django.contrib import admin
from accounts.models import *
# Register your models here.
class ContactAdmin(admin.ModelAdmin):
    list_display = ('Full_name','Email','Subject','Message')

admin.site.register(Contact,ContactAdmin)