from django.urls import path
from .import views

urlpatterns = [
    
    # Indexed page
    path('', views.home, name='home'),  

    # Main Pages
    path('about/', views.about, name='about'),  
    path('menu/', views.menu, name='menu'),

    # Categorys URLs
    path('categories/',views.categories,name="categories"),
    path('categories/<str:category_name>/', views.category_pro, name='category_pro'),

]