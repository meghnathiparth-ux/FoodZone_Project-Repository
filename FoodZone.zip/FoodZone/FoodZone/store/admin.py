from django.contrib import admin
from store.models import *

# Register your models here.

# For Category
class Category_admin(admin.ModelAdmin):
    list_display = ('id','cat_name','cat_image')

admin.site.register(Categories,Category_admin)

# For Product
class Product_admin(admin.ModelAdmin):
    list_display = ('name','category','price','image','desc')

admin.site.register(Products,Product_admin)
