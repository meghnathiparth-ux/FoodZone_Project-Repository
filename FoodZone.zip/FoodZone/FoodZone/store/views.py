from django.shortcuts import render , redirect
from django.contrib import messages
from django.contrib.auth import authenticate
from store.models import *

# Create your views here.

# Main Page View
def home(request):
    product = Products.objects.all().order_by('-id')[:8]
    if request.method == "GET":
        si = request.GET.get('searchitem')
        if si != None:
            product = Products.objects.filter( name__icontains = si)

    data = {
        "products":product
    }
    return render(request,"index.html",data)

# Other Page
def about(request):
    return render(request,"about.html")

# Menu Page
def menu(request):
    category = Categories.objects.all()
    data = {
        "category":category,
    }
    return render(request,"menu.html",data)

# Categories
def categories(request):
    return render(request,"categories.html")

def category_pro(request, category_name):
    category = Categories.objects.get(cat_name=category_name)
    products = Products.objects.filter(category=category)
    # print(category)
    # print(products)
    data = {
        "products": products,
    }
    return render(request, "categories.html", data)
