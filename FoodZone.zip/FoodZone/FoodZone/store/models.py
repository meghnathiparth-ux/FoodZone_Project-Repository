from django.db import models
import datetime
from django.contrib.auth.models import User
from autoslug import AutoSlugField
# Create your models here.

# Category Model
class Categories(models.Model):
    cat_name = models.CharField(max_length=200)
    cat_image = models.ImageField(upload_to="static/category_images",blank=True,null=True)
    slug = AutoSlugField(populate_from = 'cat_name',unique=True,null=True,default=None)
    def __str__(self):
        return self.cat_name

# Products Model
class Products(models.Model):
    name = models.CharField(max_length=400)
    category = models.ForeignKey(Categories,on_delete=models.CASCADE)
    price = models.DecimalField(default=0,decimal_places=2,max_digits=8)
    image = models.ImageField(upload_to="static/product_images")
    desc  = models.TextField(blank=True,null=True)
    slug = AutoSlugField(populate_from = 'name',unique=True,null=True,default=None)

    def __str__(self):
        return self.name
