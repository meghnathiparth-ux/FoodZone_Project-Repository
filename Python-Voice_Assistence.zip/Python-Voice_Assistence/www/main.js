// main.js (replace contents with this)
let ovel  = document.getElementById('oval');
let Wave  = document.getElementById('SoundWave');

async function startwave() {
  try {
    // Play start sound (call Python feature). The extra () returns a Promise from eel.
    // await eel.playassound()();

    // Show the listening UI
    if (ovel) ovel.style.display = "none";

    // Start the Python listening in background (non-blocking)
    const res = await eel.start_listening()(); // returns "started"
    console.log("Started listening thread:", res);

    // The actual final voice result will be sent later from Python to the JS function receive_result()
  } catch (err) {
    console.error("Error calling Python functions:", err);
  }
}

// For Show Voice Command By User
eel.expose(show_command);
function show_command(command) {
  const cmd = document.getElementById('show_cmd');
  if (cmd) {
    cmd.innerText = command;
  }
  console.log("Display Command:", command);
}


function stopwave() {
    if (ovel) ovel.style.display="block";
}

eel.expose(text_command_from_python);
function text_command_from_python(cmd) {
  console.log("Voice text from Python:", cmd);

  // Example: handle "stop" command
  if (cmd && cmd.toLowerCase() === "stop") {
    window.close();
  }

  // Restore UI
  if (ovel) ovel.style.display = "block";
}


// This function will be called from Python: eel.receive_result(result)
// eel.expose(receive_result);
function receive_result(result) {
  console.log("Received result from Python:", result);

  // If there's an error code prefix we can show it
  if (typeof result === "string" && result.startsWith("__ERROR__:")) {
    console.error("Python error:", result);
    // show fallback UI
    if (ovel) ovel.style.display = "block";
    return;
  }

  // Do something with the result string (e.g., show in console or UI)
  if (result) {
    console.log("Voice command: ", result);
    // Optionally call another eel function to process/display, or update the UI:
    // show message on screen, stop animation, etc.
  }

  // Restore UI
  if (ovel) ovel.style.display = "block";

}

// Close window event
window.addEventListener("beforeunload", async (e) => {
  try {
    await eel.stop_program()();
  } catch (err) {
    console.error("Error stopping program:", err);
  }
});
