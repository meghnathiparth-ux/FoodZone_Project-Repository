import pyttsx3 
import webbrowser
import speech_recognition as sr
import pywhatkit
import os
import subprocess
import eel

recognizer  = sr.Recognizer()

@eel.expose
def speech(str):
    engine = pyttsx3.init()
    # VOICE
    voices = engine.getProperty('voices')       # getting details of current voice
    #engine.setProperty('voice', voices[0].id)  # changing index, changes voices. o for male
    engine.setProperty('voice', voices[1].id)   # changing index, changes voices. 1 for female
    # RATE
    rate = engine.getProperty('rate')   # getting details of current speaking rate
    engine.setProperty('rate', 175)     # setting up new voice rate
    engine.say(str)
    print(str)
    engine.runAndWait()

@eel.expose
def processcommand(sen):
    sen = sen.lower()
    if sen == "open google":
        webbrowser.open("https://google.com")
        speech(sen)
    elif sen == "open youtube":
        webbrowser.open("https://youtube.com")
        speech(sen)
    elif sen == "open facebook":
        webbrowser.open("https://facebook.com")
        speech(sen)
    elif sen == "open insta":
        webbrowser.open("https://instagrame.com")
        speech(sen)
    elif sen == "open twitter":
        webbrowser.open("https://twitter.com")
        speech(sen)
    # For Good Msg
    elif sen == "good morning":
        eel.show_command("Good Morning, How Are You?")()
        speech(sen)
    elif sen == "good afternoon":
        eel.show_command("Good Afternoon, How Are You?")()
        speech(sen)
    elif sen == "good night":
        eel.show_command("Good night, How Are You?")()
        speech(sen)
    # PLAY SONG IN YOUTUBE
    elif "play" in sen:
        song = sen.replace('play', '').strip()
        print(f"🎵 Playing: {song}")
        speech("Ok, I wil Play")
        pywhatkit.playonyt(song)
    # SEARCH IN GOOGLE
    elif "search" in sen:
        content = sen.replace('search', '').strip()
        print(f"Searching: {content}")
        speech("Ok, I wil Search")
        pywhatkit.search(content)
    # Open System Folders
    elif "show" in sen.lower():
        content = sen.replace('show', '').strip()
        home = os.path.expanduser("~")
        # Common system folders
        folders = {
            "desktop": os.path.join(home, "Desktop"),
            "downloads": os.path.join(home, "Downloads"),
            "documents": os.path.join(home, "Documents"),
            "pictures": os.path.join(home, "Pictures"),
            "music": os.path.join(home, "Music"),
            "videos": os.path.join(home, "Videos")
        }

        # Open folders by name
        for key, path in folders.items():
            if key in content:
                speech(f"Showing {key}.")
                os.startfile(path)
                return

@eel.expose
def takecommand():
        speech("Initialize Alexa..")
        eel.show_command("Initialize Alexa..")()
        # Listen The Word 
        while True:
            print("Recognizing..")
            try:
                # Listening Of Command
                with sr.Microphone() as source:
                    print("Listening...")
                    eel.show_command("Listening..")()
                    audio = recognizer.listen(source, timeout=2, phrase_time_limit=2)
                    # YOUR COMMAND
                    command = recognizer.recognize_google(audio)
                    print("Your Command :- ",command)
                    # MIMI ANSWER
                    if "alexa" in command.lower():
                        speech("Yes, How Can I Help You?")
                        with sr.Microphone() as source:
                            eel.show_command("Alexa Activated..")()
                            print("alexa Activated..")
                            audio = recognizer.listen(source, timeout=6, phrase_time_limit=6)
                            # Listen Sentance
                            sentance = recognizer.recognize_google(audio)
                            processcommand(sentance)
                    elif "your name" in command.lower():
                        eel.show_command("My Name Is Alexa , And I Am Hear For You")()
                        speech("My Name Is Alexa , And I Am Hear For You")
                    elif "hu r u" in command.lower():
                        eel.show_command("I am Alexa And I Am Your Voice Assistant")()
                        speech("I am Alexa And I Am Your Voice Assistant")
                    elif "who are you" in command.lower():
                        eel.show_command("I am Alexa And I Am Your Voice Assistant")()
                        speech("I am Alexa And I Am Your Voice Assistant")
                    elif "how r u" in command.lower():
                        eel.show_command("I am Fine , what about you?")()
                        speech("I am Fine , what about you?")
                    elif "how are you" in command.lower():
                        eel.show_command("I am Fine , what about you?")()
                        speech("I am Fine , what about you?")
                    elif "stop" in command.lower():
                        eel.show_command("Ok , GoodBye")()
                        speech("Ok , GoodBye")
                        break
            except Exception as e:
                print("Error : {0}".format(e))
        return command
# text = takecommand()