from playsound import playsound
import eel

@eel.expose
def playassound():
    music_dir = "D:/Python-Voice_Assistence/engine/game-start-317318.mp3"
    playsound(music_dir)