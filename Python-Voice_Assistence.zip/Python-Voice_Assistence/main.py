# main.py
import eel
import threading
import os
import sys

# point to the folder that contains index.html
WEB_FOLDER = "www"  # change if your HTML is in a different folder

# Ensure the web folder exists
if not os.path.isdir(WEB_FOLDER):
    print(f"Error: web folder '{WEB_FOLDER}' not found. Put index.html and assets inside '{WEB_FOLDER}'.")
    sys.exit(1)

# Initialize eel
eel.init(WEB_FOLDER)

# Import your modules after eel.init so eel is available when they import if needed
from engine import command      # your command.py (contains speech, takecommand, processcommand)
from engine import features     # your features.py (contains playassound)

# PlaySound
features.playassound()

# Expose any functions (already decorated in your modules) — but we'll also provide thread-friendly wrappers.

@eel.expose
def stop_program():
    """Stop the program from JS or window close event."""
    print("Stopping program...")
    # eel.close()  # close eel window
    os._exit(0)  # force exit safely

@eel.expose
def start_listening():
    """Run takecommand in background and send result to JS."""
    def background():
        try:
            text = command.takecommand()
            eel.text_command_from_python(text)()  # call JS callback safely
        except Exception as e:
            text=print(f"__ERROR__:{repr(e)}")
            eel.text_command_from_python(f"__ERROR__:{repr(e)}")()

        # call a JS function defined in main.js to send back result
        try:
            eel.receive_result(text)
        except Exception as e:
            print("Failed to send result to JS:", e)

    threading.Thread(target=background).start()
    return "started"

if __name__ == "__main__":
    # start the eel app
    try:
        # Eel start with close callback
        eel.start("index.html", size=(520, 520), block=True)
    except (SystemExit, KeyboardInterrupt, EOFError):
        print("Program terminated by user.")
        os._exit(0)
